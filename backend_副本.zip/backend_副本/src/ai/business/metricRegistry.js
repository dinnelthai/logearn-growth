const {definitions}=require('../../analytics/businessPriorities');
const specs={
 active_users:['users','north','north','统计期内去重，不是DAU'],new_users:['users','north','north','历史覆盖影响首次观测'],returning_users:['users','north','north','历史覆盖影响回访分类'],
 activation_rate:['ratio','growth','growth','首次观测后24小时成熟'],d7:['ratio','growth','growth','第7业务日成熟队列'],weekly_core:['users','weekly',null,'7个完整UTC+7业务日'],
 registered_users:['users','growth',null,'真实注册事实；首次观测不能替代'],trade_revenue:['currency','economics',null,'收入事实覆盖及币种必须明确'],
 funnel:['report','funnel',null,'转化窗口与数据截至时间'],paths:['report','paths',null,'完整观测窗口'],product_chain:['report','product-chain',null,'真实交易覆盖未知不等于失败'],
 retention:['report','retention',null,'只比较成熟队列'],channels:['report','channels',null,'成熟分母与待成熟样本分开'],segments:['report','segments',null,'固定范围'],activities:['report','activities',null,'固定名单及活动时间窗'],quality:['report','quality',null,'各源分别报告水位与覆盖']
};
const registry=Object.fromEntries(Object.entries(specs).map(([id,[unit,queryAdapter,reviewAdapter,maturityRule]])=>[id,{id,version:'1',label:id,definition:definitions[id]||({registered_users:'真实注册账户人数，来自注册事实',trade_revenue:'已记录收入，按币种分别统计，不使用交易量替代收入'}[id])||'复用现有'+id+'分析服务的正式输出',unit,queryAdapter,reviewAdapter,maturityRule,supportedScopes:['source',...(['north','weekly','quality','economics'].includes(queryAdapter)?[]:['activityId','cohortId'])],supportedDimensions:queryAdapter==='growth'?['source','device','version']:[]} ]));
function describeMetric(id){if(!Object.hasOwn(registry,id))throw Object.assign(Error('未知指标'),{status:400});return structuredClone(registry[id]);}
module.exports={describeMetric,listMetrics:()=>Object.keys(registry).map(describeMetric)};
