import {getToken} from '../auth/authClient.js';
const BASE=import.meta.env.VITE_BACKEND_BASE_URL??'http://localhost:3001';
async function aiFetch(path,options={}){
  const token=getToken();
  const response=await fetch(BASE+path,{...options,headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})}});
  const body=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(body.error||`HTTP ${response.status}`);
  return body;
}
export const createBusinessAnalysis=params=>aiFetch('/api/ai-analysis/analyze',{method:'POST',body:JSON.stringify(params)});
export const getAnalysisList=(options={})=>aiFetch('/api/ai-analysis/list?'+new URLSearchParams({limit:'20',...options}));
export const getAnalysisDetail=id=>aiFetch('/api/ai-analysis/'+encodeURIComponent(id));
export const getJobStatus=id=>aiFetch('/api/ai-analysis/jobs/'+encodeURIComponent(id)+'/status');
export const updateSuggestionStatus=(id,updates)=>aiFetch('/api/ai-analysis/suggestions/'+encodeURIComponent(id)+'/status',{method:'PUT',body:JSON.stringify(updates)});
export const createRetrospective=(id,requestKey)=>aiFetch('/api/ai-analysis/suggestions/'+encodeURIComponent(id)+'/retrospective',{method:'POST',body:JSON.stringify({requestKey})});
export const getRetrospectives=()=>aiFetch('/api/ai-analysis/retrospectives/list');
export const getCostStats=()=>aiFetch('/api/ai-analysis/cost-stats');
export const getAvailableModels=()=>aiFetch('/api/ai/models');

export const retryAnalysis=id=>aiFetch('/api/ai-analysis/'+encodeURIComponent(id)+'/retry',{method:'POST',body:'{}'});

export const getAgentHealth=()=>aiFetch('/api/growth-agent/health');
export const getEvidence=id=>aiFetch('/api/growth-agent/evidence/'+encodeURIComponent(id));
